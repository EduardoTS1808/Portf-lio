let btnM = document.querySelector("#btn-M");
let ulLincks = document.querySelector(".lincks");
btnM.onclick = () => {
    btnM.classList.toggle('fa-times');
    ulLincks.classList.toggle('active');
}

// meu primeiro objeto criado só de exemplo
// const book = {
//     "title": " hello word",
    

//     form: {
//         name: "edu",
//         idade: "23"
//     }

// };
// const mand = {
//     name: "eduardo",
//     idade: 22,
//     cidade: "horizonte",
//     emprego: "Dev front-end"

// };


    // fim objeto